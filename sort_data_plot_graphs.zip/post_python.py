import re
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
################################################################
numeric_const_pattern = r"""					
    [-+]? # optional sign
     (?:
         (?: \d* \. \d+ ) 		# .1 .12 .123 etc 9.1 etc 98.1 etc
         |
         (?: \d+ \.? ) 			# 1. 12. 123. etc 1 12 123 etc
     )
     # followed by optional exponent part if desired
     (?: [Ee] [+-]? \d+ ) ?
     """
rx = re.compile(numeric_const_pattern, re.VERBOSE)
#################################################################

inFile1 = open("/home/asmaa/YT_tutos/openfoam/tuto_2_wingmotion/wingMotion/postProcessing/data.dat")

length_file = sum(1 for line in open("/home/asmaa/YT_tutos/openfoam/tuto_2_wingmotion/wingMotion/postProcessing/data.dat"))

data = []

l=range(0,length_file)

for i in l:
	inFile1 =open("/home/asmaa/YT_tutos/openfoam/tuto_2_wingmotion/wingMotion/postProcessing/data.dat")
	line = inFile1.readlines()[i]
	data.append(rx.findall(line))	
	inFile1.close()
#print(data)
col_names= ["iterations","Fpressure_x", "Fpressure_y", "Fpressure_z","Fviscous_x","Fviscous_y","Fviscous_z","Fporous_x","Fporous_y","Fporous_z","Mpressure_x", "Mpressure_y", "Mpressure_z","Mviscous_x","Mviscous_y","Mviscous_z","Mporous_x","Mporous_y","Mporous_z"]

df = pd.DataFrame.from_records(data,columns = col_names)

for i in col_names:
	df[i] = pd.to_numeric(df[i])
mag_Fpressure = []
mag_Fviscous  = []
for  index,row in df.iterrows(): 
    mag_Fpressure.append(np.sqrt(row["Fpressure_x"]**2 + row["Fpressure_y"]**2 + row["Fpressure_z"]**2))
    mag_Fviscous.append(np.sqrt(row["Fviscous_x"]**2 + row["Fviscous_y"]**2 + row["Fviscous_z"]**2))
    #print() 

df["Fpressure_mag"] = mag_Fpressure
df["Fviscous_mag"] = mag_Fviscous

Forces = []

for  index,row in df.iterrows(): 
    Forces.append(row["Fpressure_mag"]+row["Fviscous_mag"])

df["Forces"] = Forces

# graph Fpressure_x ###
fig1 = plt.figure(1)
plt.plot(df["iterations"],df["Fpressure_x"], "--g",df["iterations"],df["Fpressure_y"], "--r",df["iterations"],df["Fpressure_z"], "--b", df["iterations"], df["Fpressure_mag"],".k")
plt.legend(("Fpressure_x","Fpressure_y","Fpressure_z","Fpressure_mag"),loc='best')
plt.xlabel('Iterations')
plt.ylabel('Pressure forces')
plt.xlim(0,500)
fig1.savefig("F_P.png")

# graph Fviscous_x ###
fig2= plt.figure(2)
plt.plot(df["iterations"],df["Fviscous_x"], "--g",df["iterations"],df["Fviscous_y"], "--r",df["iterations"],df["Fviscous_z"], "--b", df["iterations"],df["Fviscous_mag"],".k")
plt.legend(("Fviscous_x","Fviscous_y","Fviscous_z","Fviscous_mag"),loc='best')
plt.xlabel('Iterations')
plt.ylabel('Viscous forces')
plt.xlim(0,500)
fig2.savefig("F_v.png")

# graph Forces ###
fig10= plt.figure(10)
plt.plot(df["iterations"], df["Fpressure_mag"],".r", df["iterations"],df["Fviscous_mag"],".g", df["iterations"],df["Forces"],".k")
plt.legend(("Fpressure","Fviscous","Forces"),loc='best')
plt.xlabel('Iterations')
plt.ylabel('Forces')
plt.xlim(0,500)
fig10.savefig("Forces.png")

# graph Mpressure_x ###
fig3 = plt.figure(3)
plt.plot(df["iterations"],df["Mpressure_x"], "*g",df["iterations"],df["Mpressure_y"], "*r",df["iterations"],df["Mpressure_z"], "*b")
plt.legend(("Mpressure_x","Mpressure_y","Mpressure_z"),loc='best')
plt.xlabel('Iterations')
plt.ylabel('Pressure Moment')
plt.xlim(0,500)
fig3.savefig("M_P.png")
# graph Fviscous_x ###
fig4= plt.figure(4)
plt.plot(df["iterations"],df["Mviscous_x"], "*g",df["iterations"],df["Mviscous_y"], "*r",df["iterations"],df["Mviscous_z"], "*b")
plt.legend(("Mviscous_x","Mviscous_y","Mviscous_z"),loc='best')
plt.xlabel('Iterations')
plt.ylabel('Viscous Moment')
plt.xlim(0,500)
fig4.savefig("M_v.png")

#plt.show()
