import pandas as pd
import matplotlib.pyplot as plt


l=["laminar_0-003",  "laminar_0-004",  "laminar_0-006",  "laminar_0-008",  "laminar_0-016" ]
v=["0003 m/s","0.004 m/s","0.006 m/s","0.008 m/s","0.016 m/s"]

for i in l:
	print(v[l.index(i)])

	data = pd.read_csv("/home/asmaa/YT_tutos/paraview/tuto_5/"+i+"/postProcessing/plot1.csv")

	#print(data.columns)

	#print(data["U:0"])


	##### plot U0

	fig0= plt.figure(0)
	plt.plot(data["Points:1"],data["U:0"] ,'*',label=v[l.index(i)])
	plt.xlabel("Y(m)")
	plt.ylabel("U0 (m/s)")
	plt.title("U0 versus Y")
	plt.legend(loc="center left")
	fig0.savefig("U0.png")
	#plt.show()

	##### plot U1

	fig1= plt.figure(1)
	plt.plot(data["Points:1"],data["U:1"] ,'-',label=v[l.index(i)])
	plt.xlabel("Y(m)")
	plt.ylabel("U1 (m/s)")
	plt.legend(loc="center left")
	plt.title("U1 versus Y")
	fig0.savefig("U1.png")
plt.show()
